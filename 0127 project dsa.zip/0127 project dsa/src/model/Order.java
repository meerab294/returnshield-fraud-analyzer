package model;

public class Order {

    private int orderId;
    private int userId;
    private int productId;
    private double amount;

    public Order(int orderId,
                 int userId,
                 int productId,
                 double amount) {

        this.orderId = orderId;
        this.userId = userId;
        this.productId = productId;
        this.amount = amount;
    }

    public int getOrderId() {
        return orderId;
    }

    public int getUserId() {
        return userId;
    }

    public int getProductId() {
        return productId;
    }

    public double getAmount() {
        return amount;
    }
}