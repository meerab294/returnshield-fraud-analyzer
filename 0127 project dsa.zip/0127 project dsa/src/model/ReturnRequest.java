package model;

import java.time.LocalDateTime;

public class ReturnRequest {

    private int returnId;
    private int userId;
    private String productName;
    private String reason;
    private int riskScore;
    private LocalDateTime timestamp;

    public ReturnRequest(int returnId,
                         int userId,
                         String productName,
                         String reason,
                         int riskScore) {

        this.returnId = returnId;
        this.userId = userId;
        this.productName = productName;
        this.reason = reason;
        this.riskScore = riskScore;
        this.timestamp = LocalDateTime.now();
    }

    public int getReturnId() {
        return returnId;
    }

    public int getUserId() {
        return userId;
    }

    public String getProductName() {
        return productName;
    }

    public String getReason() {
        return reason;
    }

    public int getRiskScore() {
        return riskScore;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }
}