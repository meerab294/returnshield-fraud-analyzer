package model;

public class User {

    private int userId;
    private String name;
    private String email;

    private int totalOrders;
    private int totalReturns;
    private int fraudCount;

    // NEW REAL FIELD
    private String accountType; // NORMAL / PREMIUM / FLAGGED

    public User(int userId, String name, String email,
                int totalOrders, int totalReturns, int fraudCount) {

        this.userId = userId;
        this.name = name;
        this.email = email;
        this.totalOrders = totalOrders;
        this.totalReturns = totalReturns;
        this.fraudCount = fraudCount;

        this.accountType = "NORMAL";
    }

    public void setAccountType(String type) {
        this.accountType = type;
    }

    public String getAccountType() {
        return accountType;
    }

    public int getUserId() { return userId; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public int getTotalOrders() { return totalOrders; }
    public int getTotalReturns() { return totalReturns; }
    public int getFraudCount() { return fraudCount; }
}