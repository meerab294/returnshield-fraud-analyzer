package gui;

import javax.swing.*;
import java.awt.*;

public class ReportFrame extends JFrame {

    public ReportFrame() {

        setTitle("Fraud Reports");
        setSize(800,500);
        setLocationRelativeTo(null);

        JTextArea reportArea =
                new JTextArea();

        reportArea.setFont(
                new Font(
                        "Monospaced",
                        Font.PLAIN,
                        14));

        reportArea.setText(

                "========== FRAUD REPORT ==========\n\n"

                + "Total Users: 1200\n\n"

                + "Total Returns: 530\n\n"

                + "Fraud Cases: 67\n\n"

                + "High Risk Users: 22\n\n"

                + "Estimated Fraud Loss:\n"

                + "$12,500\n\n"

                + "Top Risk Category:\n"

                + "Electronics\n\n"

                + "Most Returned Product:\n"

                + "Wireless Headphones\n\n"

                + "=================================="
        );

        add(new JScrollPane(reportArea));

        setVisible(true);
    }
}