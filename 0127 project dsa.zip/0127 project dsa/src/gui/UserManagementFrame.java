package gui;

import dsa.UserStore;
import model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class UserManagementFrame extends JFrame {

    private JTextField idField;
    private JTextField nameField;
    private JTextField emailField;

    private JTable table;
    private DefaultTableModel model;

    private UserStore store;

    public UserManagementFrame() {

        store = new UserStore();

        setTitle("User Management");
        setSize(900,600);
        setLocationRelativeTo(null);

        setLayout(new BorderLayout());

        //----------------------------------
        // Top Form
        //----------------------------------

        JPanel formPanel = new JPanel();

        formPanel.add(new JLabel("ID"));
        idField = new JTextField(5);

        formPanel.add(idField);

        formPanel.add(new JLabel("Name"));
        nameField = new JTextField(10);

        formPanel.add(nameField);

        formPanel.add(new JLabel("Email"));
        emailField = new JTextField(15);

        formPanel.add(emailField);

        JButton addBtn =
                new JButton("Add User");

        JButton searchBtn =
                new JButton("Search");

        formPanel.add(addBtn);
        formPanel.add(searchBtn);

        //----------------------------------
        // Table
        //----------------------------------

        String[] columns = {
                "ID",
                "Name",
                "Email",
                "Orders",
                "Returns",
                "Frauds"
        };

        model =
                new DefaultTableModel(columns,0);

        table =
                new JTable(model);

        JScrollPane scroll =
                new JScrollPane(table);

        loadUsers();

        //----------------------------------
        // Add User
        //----------------------------------

        addBtn.addActionListener(e -> {

            try {

                int id =
                        Integer.parseInt(
                                idField.getText());

                String name =
                        nameField.getText();

                String email =
                        emailField.getText();

                User user =
                        new User(
                                id,
                                name,
                                email,
                                0,
                                0,
                                0);

                store.addUser(user);

                model.addRow(new Object[]{

                        user.getUserId(),
                        user.getName(),
                        user.getEmail(),
                        user.getTotalOrders(),
                        user.getTotalReturns(),
                        user.getFraudCount()
                });

                JOptionPane.showMessageDialog(
                        null,
                        "User Added Successfully");

            }

            catch(Exception ex){

                JOptionPane.showMessageDialog(
                        null,
                        "Invalid Input");
            }

        });

        //----------------------------------
        // Search User
        //----------------------------------

        searchBtn.addActionListener(e -> {

            try {

                int id =
                        Integer.parseInt(
                                idField.getText());

                User user =
                        store.searchUser(id);

                if(user == null){

                    JOptionPane.showMessageDialog(
                            null,
                            "User Not Found");
                }

                else{

                    JOptionPane.showMessageDialog(
                            null,
                            "User Found:\n\n"
                                    + user.getName()
                                    + "\n"
                                    + user.getEmail());
                }

            }

            catch(Exception ex){

                JOptionPane.showMessageDialog(
                        null,
                        "Invalid ID");
            }

        });

        add(formPanel,
                BorderLayout.NORTH);

        add(scroll,
                BorderLayout.CENTER);

        setVisible(true);
    }

    private void loadUsers(){

        for(User user :
                store.getUsers().values()){

            model.addRow(new Object[]{

                    user.getUserId(),
                    user.getName(),
                    user.getEmail(),
                    user.getTotalOrders(),
                    user.getTotalReturns(),
                    user.getFraudCount()
            });
        }
    }
}