package gui;

import model.ReturnRequest;
import dsa.PriorityReturnQueue;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class ReturnManagementFrame extends JFrame {

    private JTextField returnIdField;
    private JTextField userIdField;
    private JTextField productField;
    private JTextField riskField;

    private JTable table;
    private DefaultTableModel model;

    private PriorityReturnQueue queue;

    public ReturnManagementFrame() {

        queue = new PriorityReturnQueue();

        setTitle("Return Management");
        setSize(1000,600);
        setLocationRelativeTo(null);

        setLayout(new BorderLayout());

        //---------------------------------
        // Form Panel
        //---------------------------------

        JPanel form = new JPanel();

        form.add(new JLabel("Return ID"));

        returnIdField = new JTextField(5);
        form.add(returnIdField);

        form.add(new JLabel("User ID"));

        userIdField = new JTextField(5);
        form.add(userIdField);

        form.add(new JLabel("Product"));

        productField = new JTextField(10);
        form.add(productField);

        form.add(new JLabel("Risk"));

        riskField = new JTextField(5);
        form.add(riskField);

        JButton addBtn =
                new JButton("Add Return");

        JButton processBtn =
                new JButton("Process Highest Risk");

        form.add(addBtn);
        form.add(processBtn);

        //---------------------------------
        // Table
        //---------------------------------

        String[] columns = {

                "Return ID",
                "User ID",
                "Product",
                "Risk Score"
        };

        model =
                new DefaultTableModel(columns,0);

        table =
                new JTable(model);

        JScrollPane scroll =
                new JScrollPane(table);

        //---------------------------------
        // Add Return
        //---------------------------------

        addBtn.addActionListener(e -> {

            try {

                int returnId =
                        Integer.parseInt(
                                returnIdField.getText());

                int userId =
                        Integer.parseInt(
                                userIdField.getText());

                String product =
                        productField.getText();

                int risk =
                        Integer.parseInt(
                                riskField.getText());

                ReturnRequest request =
                        new ReturnRequest(
                                returnId,
                                userId,
                                product,
                                "Customer Return",
                                risk);

                queue.addRequest(request);

                model.addRow(new Object[]{

                        returnId,
                        userId,
                        product,
                        risk
                });

                JOptionPane.showMessageDialog(
                        null,
                        "Return Added");

            }

            catch(Exception ex){

                JOptionPane.showMessageDialog(
                        null,
                        "Invalid Data");
            }

        });

        //---------------------------------
        // Process Return
        //---------------------------------

        processBtn.addActionListener(e -> {

            if(queue.isEmpty()){

                JOptionPane.showMessageDialog(
                        null,
                        "No Pending Returns");

                return;
            }

            ReturnRequest request =
                    queue.processNext();

            JOptionPane.showMessageDialog(
                    null,
                    "Processing Return\n\n" +
                    "Return ID: "
                    + request.getReturnId()
                    + "\nRisk Score: "
                    + request.getRiskScore());
        });

        add(form,
                BorderLayout.NORTH);

        add(scroll,
                BorderLayout.CENTER);

        setVisible(true);
    }
}