package gui;

import dsa.FraudDetector;
import dsa.UserStore;
import model.User;

import javax.swing.*;
import java.awt.*;

public class FraudAnalysisFrame extends JFrame {

    private JTextField userIdField;
    private JTextArea resultArea;

    public FraudAnalysisFrame() {

        setTitle("Fraud Analysis Engine");
        setSize(700,500);
        setLocationRelativeTo(null);

        setLayout(new BorderLayout());

        //----------------------------------
        // Top Panel
        //----------------------------------

        JPanel topPanel = new JPanel();

        JLabel lbl =
                new JLabel("Enter User ID:");

        userIdField =
                new JTextField(10);

        JButton analyzeBtn =
                new JButton("Analyze");

        topPanel.add(lbl);
        topPanel.add(userIdField);
        topPanel.add(analyzeBtn);

        //----------------------------------
        // Result Area
        //----------------------------------

        resultArea =
                new JTextArea();

        resultArea.setEditable(false);

        JScrollPane scroll =
                new JScrollPane(resultArea);

        //----------------------------------
        // Action
        //----------------------------------

        analyzeBtn.addActionListener(e -> {

            try {

                int id =
                        Integer.parseInt(
                                userIdField.getText());

                UserStore store =
                        new UserStore();

                User user =
                        store.searchUser(id);

                if(user == null){

                    resultArea.setText(
                            "User Not Found");
                    return;
                }

                int score =
                        FraudDetector
                                .calculateRiskScore(user);

                String level =
                        FraudDetector
                                .getRiskLevel(score);

                String report =
                        "===== FRAUD ANALYSIS REPORT =====\n\n" +

                        "User ID: "
                        + user.getUserId()
                        + "\n\n" +

                        "Name: "
                        + user.getName()
                        + "\n\n" +

                        "Orders: "
                        + user.getTotalOrders()
                        + "\n\n" +

                        "Returns: "
                        + user.getTotalReturns()
                        + "\n\n" +

                        "Previous Frauds: "
                        + user.getFraudCount()
                        + "\n\n" +

                        "Risk Score: "
                        + score
                        + "\n\n" +

                        "Risk Level: "
                        + level
                        + "\n\n";

                if(level.equals("HIGH")){

                    report +=
                            "Recommendation:\n" +
                            "Manual Review Required\n" +
                            "Potential Fraud User";
                }

                else if(level.equals("MEDIUM")){

                    report +=
                            "Recommendation:\n" +
                            "Monitor Future Returns";
                }

                else{

                    report +=
                            "Recommendation:\n" +
                            "Auto Approve Return";
                }

                resultArea.setText(report);

            }

            catch(Exception ex){

                JOptionPane.showMessageDialog(
                        null,
                        "Invalid User ID");
            }

        });

        //----------------------------------
        // Add Components
        //----------------------------------

        add(topPanel,
                BorderLayout.NORTH);

        add(scroll,
                BorderLayout.CENTER);

        setVisible(true);
    }
}