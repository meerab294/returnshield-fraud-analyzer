package gui;

import dsa.*;
import model.*;
import service.FraudService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class DashboardFrame extends JFrame {

    private JTable table;

    public DashboardFrame() {

        setTitle("FraudGuard Pro - Enterprise Fraud Detection System");
        setSize(1350, 800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // ================= SIDEBAR =================
        JPanel sidebar = new JPanel();
        sidebar.setPreferredSize(new Dimension(240, 800));
        sidebar.setBackground(new Color(20, 20, 20));
        sidebar.setLayout(new GridLayout(10, 1, 8, 8));

        JButton dashboardBtn = new JButton("Dashboard");
        JButton usersBtn = new JButton("Users");
        JButton returnsBtn = new JButton("Returns");
        JButton fraudBtn = new JButton("Fraud Engine");
        JButton analyzeBtn = new JButton("Analyze Selected User");
        JButton reportsBtn = new JButton("Reports");
        JButton exitBtn = new JButton("Exit");

        sidebar.add(dashboardBtn);
        sidebar.add(usersBtn);
        sidebar.add(returnsBtn);
        sidebar.add(fraudBtn);
        sidebar.add(analyzeBtn);
        sidebar.add(reportsBtn);
        sidebar.add(exitBtn);

        // ================= TABLE =================
        String[] cols = {
                "ID", "Name", "Orders", "Returns",
                "Fraud", "Score", "Level"
        };

        DefaultTableModel model = new DefaultTableModel(cols, 0);

        UserStore store = new UserStore();

        for (User u : store.getUsers().values()) {

            int score = FraudDetector.calculateRiskScore(u);
            String level = FraudDetector.getRiskLevel(score);

            model.addRow(new Object[]{
                    u.getUserId(),
                    u.getName(),
                    u.getTotalOrders(),
                    u.getTotalReturns(),
                    u.getFraudCount(),
                    score,
                    level
            });
        }

        table = new JTable(model);

        JScrollPane scroll = new JScrollPane(table);

        // ================= CENTER =================
        JPanel center = new JPanel(new BorderLayout());

        JLabel title = new JLabel("FraudGuard Enterprise Control Panel");
        title.setFont(new Font("Arial", Font.BOLD, 26));

        center.add(title, BorderLayout.NORTH);
        center.add(scroll, BorderLayout.CENTER);

        // ================= ANALYZE BUTTON (REAL FEATURE) =================
        analyzeBtn.addActionListener(e -> {

            int row = table.getSelectedRow();

            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Select a user first!");
                return;
            }

            int userId = (int) table.getValueAt(row, 0);

            User user = store.searchUser(userId);

            String report = FraudService.analyzeUser(user);

            JTextArea area = new JTextArea(report);
            area.setFont(new Font("Monospaced", Font.PLAIN, 14));

            JOptionPane.showMessageDialog(
                    this,
                    new JScrollPane(area),
                    "Fraud Analysis Report",
                    JOptionPane.INFORMATION_MESSAGE
            );
        });

        // ================= BUTTONS =================
        usersBtn.addActionListener(e -> new UserManagementFrame());
        returnsBtn.addActionListener(e -> new ReturnManagementFrame());
        fraudBtn.addActionListener(e -> JOptionPane.showMessageDialog(this, "Fraud Engine Running..."));
        reportsBtn.addActionListener(e -> new ReportFrame());
        exitBtn.addActionListener(e -> System.exit(0));

        // ================= ADD =================
        add(sidebar, BorderLayout.WEST);
        add(center, BorderLayout.CENTER);

        setVisible(true);
    }
}