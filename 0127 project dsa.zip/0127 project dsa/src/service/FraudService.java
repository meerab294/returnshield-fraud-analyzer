package service;

import dsa.FraudDetector;
import model.User;

public class FraudService {

    public static String analyzeUser(User user) {

        int score = FraudDetector.calculateRiskScore(user);
        String level = FraudDetector.getRiskLevel(score);

        StringBuilder sb = new StringBuilder();

        sb.append("=== FRAUD ANALYSIS REPORT ===\n\n");
        sb.append("User: ").append(user.getName()).append("\n");
        sb.append("Score: ").append(score).append("\n");
        sb.append("Level: ").append(level).append("\n\n");

        if (score > 70) {
            sb.append("ACTION: BLOCK TEMPORARILY\n");
            sb.append("REASON: High fraud probability\n");
        } else if (score > 40) {
            sb.append("ACTION: SEND TO MANUAL REVIEW\n");
        } else {
            sb.append("ACTION: APPROVE\n");
        }

        return sb.toString();
    }
}