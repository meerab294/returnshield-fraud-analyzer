package dsa;

public class ReturnBST {

    class Node {

        int returnId;
        Node left;
        Node right;

        Node(int id){
            this.returnId = id;
        }
    }

    private Node root;

    public void insert(int id){

        root = insertRec(root,id);
    }

    private Node insertRec(Node root,int id){

        if(root == null){
            return new Node(id);
        }

        if(id < root.returnId){
            root.left = insertRec(root.left,id);
        }
        else{
            root.right = insertRec(root.right,id);
        }

        return root;
    }

    public boolean search(int id){

        return searchRec(root,id);
    }

    private boolean searchRec(Node root,int id){

        if(root == null){
            return false;
        }

        if(root.returnId == id){
            return true;
        }

        if(id < root.returnId){
            return searchRec(root.left,id);
        }

        return searchRec(root.right,id);
    }
}