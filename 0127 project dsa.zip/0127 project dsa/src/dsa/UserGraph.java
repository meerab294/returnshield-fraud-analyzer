package dsa;

import java.util.*;

public class UserGraph {

    private Map<Integer,
            List<Integer>> graph;

    public UserGraph(){

        graph = new HashMap<>();
    }

    public void connectUsers(
            int user1,
            int user2){

        graph.putIfAbsent(
                user1,
                new ArrayList<>());

        graph.get(user1)
                .add(user2);
    }

    public void displayConnections(){

        for(Integer user :
                graph.keySet()){

            System.out.println(
                "User "
                + user
                + " connected to "
                + graph.get(user));
        }
    }
}