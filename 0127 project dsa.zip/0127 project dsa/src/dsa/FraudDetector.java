package dsa;

import model.User;

public class FraudDetector {

    public static int calculateRiskScore(User user) {

        int score = 0;

        double ratio = (user.getTotalOrders() == 0)
                ? 0
                : (double) user.getTotalReturns() / user.getTotalOrders();

        // CORE ENGINE (industry-style weighted system)
        score += ratio * 55;                 // return abuse
        score += user.getFraudCount() * 25;  // history
        score += (user.getTotalReturns() > 10 ? 20 : 0);
        score += (user.getTotalOrders() < 5 ? 15 : 0);

        // anomaly detection
        if (user.getTotalReturns() > user.getTotalOrders()) {
            score += 20;
        }

        return Math.min(score, 100);
    }

    public static String getRiskLevel(int score) {

        if (score <= 30) return "LOW";
        if (score <= 60) return "MEDIUM";
        return "HIGH";
    }
}