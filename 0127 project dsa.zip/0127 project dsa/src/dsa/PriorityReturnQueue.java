package dsa;

import model.ReturnRequest;
import java.util.PriorityQueue;

public class PriorityReturnQueue {

    private PriorityQueue<ReturnRequest> queue;

    public PriorityReturnQueue() {

        queue = new PriorityQueue<>(
                (a, b) -> b.getRiskScore() - a.getRiskScore()
        );
    }

    public void addRequest(ReturnRequest r) {
        queue.add(r);
    }

    public ReturnRequest processNext() {
        return queue.poll();
    }

    public boolean isEmpty() {
        return queue.isEmpty();
    }

    public int size() {
        return queue.size();
    }
}