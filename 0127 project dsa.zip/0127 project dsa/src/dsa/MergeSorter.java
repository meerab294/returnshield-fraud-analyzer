package dsa;

import model.User;
import java.util.ArrayList;
import java.util.Comparator;

public class MergeSorter {

    public static void sortUsersByRisk(
            ArrayList<User> users){

        users.sort(
            Comparator.comparingInt(
                FraudDetector::calculateRiskScore)
                .reversed());
    }
}