CREATE DATABASE FraudGuard;

USE FraudGuard;

CREATE TABLE users(

user_id INT PRIMARY KEY,
name VARCHAR(100),
orders_count INT,
returns_count INT,
fraud_count INT

);

CREATE TABLE returns(

return_id INT PRIMARY KEY,
user_id INT,
product_name VARCHAR(100),
risk_score INT,

FOREIGN KEY(user_id)
REFERENCES users(user_id)

);