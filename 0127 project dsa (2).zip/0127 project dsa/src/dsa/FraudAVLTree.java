package dsa;

public class FraudAVLTree {

    class Node {

        int score;
        Node left;
        Node right;

        Node(int score) {

            this.score = score;
        }
    }

    private Node root;

    public void insert(int score) {

        root = insertRec(root, score);
    }

    private Node insertRec(
            Node root,
            int score) {

        if(root == null) {

            return new Node(score);
        }

        if(score < root.score) {

            root.left =
                    insertRec(
                            root.left,
                            score);
        }

        else {

            root.right =
                    insertRec(
                            root.right,
                            score);
        }

        return root;
    }
}