package dsa;

import java.util.HashMap;

public class FraudTrie {

    class Node {

        HashMap<Character, Node> children =
                new HashMap<>();

        boolean end;
    }

    private Node root;

    public FraudTrie() {

        root = new Node();
    }

    public void insert(String word) {

        Node current = root;

        for(char c : word.toCharArray()) {

            current.children.putIfAbsent(
                    c,
                    new Node());

            current =
                    current.children.get(c);
        }

        current.end = true;
    }

    public boolean search(String word) {

        Node current = root;

        for(char c : word.toCharArray()) {

            if(!current.children.containsKey(c)) {

                return false;
            }

            current =
                    current.children.get(c);
        }

        return current.end;
    }
}