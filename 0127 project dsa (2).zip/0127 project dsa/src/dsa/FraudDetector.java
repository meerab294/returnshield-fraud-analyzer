package dsa;

import model.User;

public class FraudDetector {

    public static int calculateRiskScore(User user) {

        int score = 0;

        double ratio = 0;

        if(user.getTotalOrders() > 0) {

            ratio =
                    (double)
                    user.getTotalReturns()
                    /
                    user.getTotalOrders();
        }

        score += (int)(ratio * 40);

        score += user.getFraudCount() * 20;

        if(user.getAccountAge() < 6) {
            score += 15;
        }

        if(user.getTotalReturns() > 10) {
            score += 20;
        }

        if(score > 100) {
            score = 100;
        }

        return score;
    }

    public static String getRiskLevel(int score) {

        if(score <= 30) {
            return "SAFE";
        }

        if(score <= 60) {
            return "MEDIUM";
        }

        if(score <= 80) {
            return "HIGH";
        }

        return "CRITICAL";
    }
}