package dsa;

import java.util.LinkedHashMap;
import java.util.Map;

public class LRUCache {

    private final int capacity;

    private LinkedHashMap<Integer,Integer> cache;

    public LRUCache(int capacity) {

        this.capacity = capacity;

        cache =
                new LinkedHashMap<Integer,Integer>(
                        capacity,
                        0.75f,
                        true) {

                    protected boolean removeEldestEntry(
                            Map.Entry<Integer,Integer> eldest) {

                        return size() > capacity;
                    }
                };
    }

    public void put(int userId,
                    int risk) {

        cache.put(userId, risk);
    }

    public Integer get(int userId) {

        return cache.get(userId);
    }

    public void display() {

        System.out.println(cache);
    }
}