package dsa;

public class SlidingWindowDetector {

    public static boolean suspiciousReturns(
            int returns,
            int days) {

        return returns >= 5
                &&
                days <= 7;
    }
}