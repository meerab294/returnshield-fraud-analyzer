package dsa;

import model.User;
import java.util.HashMap;

public class UserStore {

    private HashMap<Integer, User> users;

    public UserStore() {

        users = new HashMap<>();

        loadSampleUsers();
    }

    private void loadSampleUsers() {

        users.put(1,
                new User(
                        1,
                        "Ali Khan",
                        "ali@gmail.com",
                        30,
                        2,
                        0,
                        "Lahore",
                        24,
                        "DEV101"));

        users.put(2,
                new User(
                        2,
                        "Ahmed Raza",
                        "ahmed@gmail.com",
                        20,
                        15,
                        3,
                        "Karachi",
                        3,
                        "DEV555"));

        users.put(3,
                new User(
                        3,
                        "Sara Noor",
                        "sara@gmail.com",
                        40,
                        1,
                        0,
                        "Islamabad",
                        36,
                        "DEV111"));

        users.put(4,
                new User(
                        4,
                        "Usman",
                        "usman@gmail.com",
                        18,
                        12,
                        2,
                        "Faisalabad",
                        4,
                        "DEV555"));
    }

    public HashMap<Integer, User> getUsers() {
        return users;
    }

    public User searchUser(int id) {
        return users.get(id);
    }

    public void addUser(User user) {
        users.put(user.getUserId(), user);
    }
}