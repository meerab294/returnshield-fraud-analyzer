package model;

public class User {

    private int userId;
    private String name;
    private String email;
    private int totalOrders;
    private int totalReturns;
    private int fraudCount;

    // NEW REAL-WORLD FIELDS
    private String city;
    private int accountAge;
    private String deviceId;

    public User(
            int userId,
            String name,
            String email,
            int totalOrders,
            int totalReturns,
            int fraudCount,
            String city,
            int accountAge,
            String deviceId) {

        this.userId = userId;
        this.name = name;
        this.email = email;
        this.totalOrders = totalOrders;
        this.totalReturns = totalReturns;
        this.fraudCount = fraudCount;
        this.city = city;
        this.accountAge = accountAge;
        this.deviceId = deviceId;
    }

    public int getUserId() {
        return userId;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public int getTotalOrders() {
        return totalOrders;
    }

    public int getTotalReturns() {
        return totalReturns;
    }

    public int getFraudCount() {
        return fraudCount;
    }

    public String getCity() {
        return city;
    }

    public int getAccountAge() {
        return accountAge;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setFraudCount(int fraudCount) {
        this.fraudCount = fraudCount;
    }

    @Override
    public String toString() {

        return userId + " "
                + name
                + " "
                + city;
    }
}