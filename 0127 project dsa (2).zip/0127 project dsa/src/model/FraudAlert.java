package model;

public class FraudAlert {

    private int alertId;
    private int userId;
    private String reason;
    private String severity;

    public FraudAlert(
            int alertId,
            int userId,
            String reason,
            String severity) {

        this.alertId = alertId;
        this.userId = userId;
        this.reason = reason;
        this.severity = severity;
    }

    public int getAlertId() {
        return alertId;
    }

    public int getUserId() {
        return userId;
    }

    public String getReason() {
        return reason;
    }

    public String getSeverity() {
        return severity;
    }
}