package model;

public class UserSession {

    private int userId;
    private String deviceId;
    private String ipAddress;

    public UserSession(
            int userId,
            String deviceId,
            String ipAddress) {

        this.userId = userId;
        this.deviceId = deviceId;
        this.ipAddress = ipAddress;
    }

    public int getUserId() {
        return userId;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public String getIpAddress() {
        return ipAddress;
    }
}