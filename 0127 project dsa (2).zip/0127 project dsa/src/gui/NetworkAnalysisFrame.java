package gui;

import javax.swing.*;
import java.awt.*;

public class NetworkAnalysisFrame extends JFrame {

    public NetworkAnalysisFrame() {

        setTitle("Fraud Network Analysis");

        setSize(700,400);

        setLocationRelativeTo(null);

        JTextArea area =
                new JTextArea();

        area.setFont(
                new Font(
                        "Monospaced",
                        Font.BOLD,
                        16));

        area.setText(

                "USER CONNECTIONS\n\n"

                + "User 2 ---> User 4\n"

                + "Shared Device: DEV555\n\n"

                + "User 4 ---> User 8\n"

                + "Shared Address\n\n"

                + "Possible Fraud Ring Detected");

        add(new JScrollPane(area));

        setVisible(true);
    }
}