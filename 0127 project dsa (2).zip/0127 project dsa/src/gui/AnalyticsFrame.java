package gui;

import javax.swing.*;
import java.awt.*;

public class AnalyticsFrame extends JFrame {

    public AnalyticsFrame() {

        setTitle("Fraud Analytics");
        setSize(800,500);
        setLocationRelativeTo(null);

        JTextArea area =
                new JTextArea();

        area.setFont(
                new Font(
                        "Monospaced",
                        Font.PLAIN,
                        16));

        area.setText(

                "FRAUD ANALYTICS\n\n"

                + "Top Risk User: Ahmed Raza\n\n"

                + "Highest Risk Score: 88\n\n"

                + "Most Returned Product:\n"

                + "Wireless Headphones\n\n"

                + "Most Fraud City:\n"

                + "Karachi\n\n"

                + "Fraud Cases:\n"

                + "67\n\n"

                + "Critical Alerts:\n"

                + "12\n");

        add(new JScrollPane(area));

        setVisible(true);
    }
}