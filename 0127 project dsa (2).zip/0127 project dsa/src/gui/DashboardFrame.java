package gui;

import dsa.FraudDetector;
import dsa.UserStore;
import model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class DashboardFrame extends JFrame {

    private JTable table;

    public DashboardFrame() {

        setTitle("FraudGuard Pro - Fraud Analytics Platform");
        setSize(1400, 800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(new BorderLayout());

        //----------------------------------
        // SIDEBAR
        //----------------------------------

        JPanel sidebar = new JPanel();
        sidebar.setPreferredSize(new Dimension(230, 800));
        sidebar.setBackground(new Color(35, 35, 35));
        sidebar.setLayout(new GridLayout(10, 1, 10, 10));

        JButton dashboardBtn = new JButton("Dashboard");
        JButton usersBtn = new JButton("Users");
        JButton returnsBtn = new JButton("Returns");
        JButton fraudBtn = new JButton("Fraud Analysis");
        JButton analyticsBtn = new JButton("Analytics");
        JButton networkBtn = new JButton("Fraud Network");
        JButton alertBtn = new JButton("Alerts");
        JButton reportsBtn = new JButton("Reports");
        JButton exitBtn = new JButton("Exit");

        sidebar.add(dashboardBtn);
        sidebar.add(usersBtn);
        sidebar.add(returnsBtn);
        sidebar.add(fraudBtn);
        sidebar.add(analyticsBtn);
        sidebar.add(networkBtn);
        sidebar.add(alertBtn);
        sidebar.add(reportsBtn);
        sidebar.add(exitBtn);

        //----------------------------------
        // HEADER
        //----------------------------------

        JLabel title = new JLabel(
                "FraudGuard Pro Dashboard",
                SwingConstants.CENTER);

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        30));

        title.setBorder(
                BorderFactory.createEmptyBorder(
                        20,
                        20,
                        20,
                        20));

        //----------------------------------
        // STATISTICS CARDS
        //----------------------------------

        JPanel cards = new JPanel(
                new GridLayout(
                        2,
                        3,
                        15,
                        15));

        cards.setBorder(
                BorderFactory.createEmptyBorder(
                        15,
                        15,
                        15,
                        15));

        cards.add(createCard(
                "Total Users",
                "1200",
                new Color(52,152,219)));

        cards.add(createCard(
                "Returns",
                "530",
                new Color(46,204,113)));

        cards.add(createCard(
                "Fraud Cases",
                "67",
                new Color(231,76,60)));

        cards.add(createCard(
                "High Risk",
                "22",
                new Color(241,196,15)));

        cards.add(createCard(
                "Critical Alerts",
                "12",
                new Color(192,57,43)));

        cards.add(createCard(
                "Fraud Rings",
                "4",
                new Color(155,89,182)));

        //----------------------------------
        // TABLE
        //----------------------------------

        String[] columns = {

                "ID",
                "Name",
                "City",
                "Orders",
                "Returns",
                "Frauds",
                "Risk Score",
                "Risk Level",
                "Device"
        };

        DefaultTableModel model =
                new DefaultTableModel(columns, 0);

        UserStore store =
                new UserStore();

        for (User user :
                store.getUsers().values()) {

            int score =
                    FraudDetector
                    .calculateRiskScore(user);

            String level =
                    FraudDetector
                    .getRiskLevel(score);

            model.addRow(new Object[] {

                    user.getUserId(),
                    user.getName(),
                    user.getCity(),
                    user.getTotalOrders(),
                    user.getTotalReturns(),
                    user.getFraudCount(),
                    score,
                    level,
                    user.getDeviceId()
            });
        }

        table = new JTable(model);

        table.setRowHeight(30);

        table.getTableHeader().setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        14));

        JScrollPane scroll =
                new JScrollPane(table);

        //----------------------------------
        // CENTER PANEL
        //----------------------------------

        JPanel center =
                new JPanel(
                        new BorderLayout());

        center.add(
                title,
                BorderLayout.NORTH);

        center.add(
                cards,
                BorderLayout.CENTER);

        center.add(
                scroll,
                BorderLayout.SOUTH);

        //----------------------------------
        // BUTTON ACTIONS
        //----------------------------------

        usersBtn.addActionListener(e -> {

            new UserManagementFrame();
        });

        returnsBtn.addActionListener(e -> {

            new ReturnManagementFrame();
        });

        fraudBtn.addActionListener(e -> {

            new FraudAnalysisFrame();
        });

        analyticsBtn.addActionListener(e -> {

            new AnalyticsFrame();
        });

        networkBtn.addActionListener(e -> {

            new NetworkAnalysisFrame();
        });

        alertBtn.addActionListener(e -> {

            new AlertManagementFrame();
        });

        reportsBtn.addActionListener(e -> {

            new ReportFrame();
        });

        exitBtn.addActionListener(e -> {

            System.exit(0);
        });

        //----------------------------------
        // ADD PANELS
        //----------------------------------

        add(sidebar,
                BorderLayout.WEST);

        add(center,
                BorderLayout.CENTER);

        setVisible(true);
    }

    private JPanel createCard(
            String title,
            String value,
            Color color) {

        JPanel panel =
                new JPanel();

        panel.setBackground(color);

        panel.setLayout(
                new BorderLayout());

        JLabel lblTitle =
                new JLabel(
                        title,
                        SwingConstants.CENTER);

        JLabel lblValue =
                new JLabel(
                        value,
                        SwingConstants.CENTER);

        lblTitle.setForeground(
                Color.WHITE);

        lblValue.setForeground(
                Color.WHITE);

        lblTitle.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        16));

        lblValue.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        30));

        panel.add(
                lblTitle,
                BorderLayout.NORTH);

        panel.add(
                lblValue,
                BorderLayout.CENTER);

        return panel;
    }
}