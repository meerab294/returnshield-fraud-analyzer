package gui;

import dsa.FraudDetector;
import dsa.UserStore;
import model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class UserManagementFrame extends JFrame {

    public UserManagementFrame() {

        setTitle("User Management");

        setSize(900,500);

        setLocationRelativeTo(null);

        String[] columns = {
                "ID",
                "Name",
                "City",
                "Orders",
                "Returns",
                "Risk"
        };

        DefaultTableModel model =
                new DefaultTableModel(columns,0);

        UserStore store =
                new UserStore();

        for(User user :
                store.getUsers().values()) {

            int score =
                    FraudDetector
                    .calculateRiskScore(user);

            model.addRow(new Object[]{

                    user.getUserId(),
                    user.getName(),
                    user.getCity(),
                    user.getTotalOrders(),
                    user.getTotalReturns(),
                    score
            });
        }

        JTable table =
                new JTable(model);

        add(new JScrollPane(table));

        setVisible(true);
    }
}