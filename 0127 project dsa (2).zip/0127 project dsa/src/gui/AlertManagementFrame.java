package gui;

import javax.swing.*;
import java.awt.*;

public class AlertManagementFrame extends JFrame {

    public AlertManagementFrame() {

        setTitle("Fraud Alerts");

        setSize(700,400);

        setLocationRelativeTo(null);

        JTextArea alerts =
                new JTextArea();

        alerts.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        16));

        alerts.setText(

                "ALERT 101\n"

                + "User 2\n"

                + "Critical Risk\n\n"

                + "ALERT 102\n"

                + "User 4\n"

                + "Shared Device\n\n"

                + "ALERT 103\n"

                + "Multiple Returns");

        add(new JScrollPane(alerts));

        setVisible(true);
    }
}